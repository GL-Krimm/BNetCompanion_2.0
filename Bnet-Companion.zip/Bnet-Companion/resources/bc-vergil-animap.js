bcVergilAnimap = [
	{x:2,ms:66},
	{x:5,ms:66},
	{x:0,ms:66},
	{x:0,ms:66},
	{x:0,ms:66},
	{x:5,ms:66},
	{x:2,ms:66},
	{x:5,ms:66},
	{x:0,ms:66},
	{x:0,ms:66},
	{x:0,ms:66},
	{x:5,ms:66},
	{x:2,ms:66}
];