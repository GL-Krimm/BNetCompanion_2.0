bcTextResources = {
	privacyStorage:'Bnet Companion locally s stores basic information about your Bungie.net profile and your Twitter profile, should you choose to connect Bungie Browser to either of these services.',
	privacyPrivateDataPolicy:'We respect your privacy, and no stored data will be sent to or shared with the author or any third parties.',
	tosTradeMarks:"Bungie, Bungie Mobile, Bungie.net, and all related assets such as images, brand names, and logos, are the sole property of Bungie Inc. Registered trademarked names, images, logos, and assets are used in accordance with Bungie Inc's rights and guidelines.",
	tosLicense:"Bnet Companion is free software. Distribution of Bnet Companion is encouraged as long as it is not sold or distributed for donations",
	aboutDescription:"The author ( Brandon McMullin ) created BNet Companion as a labor of love, inspired by Bungie Mobile.",
	aboutLegal:"The author and any contributors are not affiliated with Bungie, Bungie's partners, or Bungie's subsidiaries.",
	aboutLove:"From a huge Bungie fan,",
	aboutTagline:"Per Audica Ad Astra.",
	settingsConnectWithTwitter:"Connecting to Twitter helps ensure Bnet Companion can reliably retrieve Tweets from Bungie"
};