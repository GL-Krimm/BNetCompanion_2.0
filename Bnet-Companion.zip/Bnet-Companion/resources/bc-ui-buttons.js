bcMenuButtons = [
				//{title:'Profile',img:'profile.png',targetPage:'profile'},
				{title:'News',img:'news.png',targetPage:'news',rootPage:true},
				{title:'More',img:'more.png',targetPage:'more'}
	];
	
bcMorePageButtons = [
		{title:'Bungie.net Website',img:'bnet.gif',externPage:'http://www.bungie.net'},
		{title:'Privacy Policy',img:'Carnage_Zone.png',targetPage:'privacy'},
		{title:'Terms of Use',img:'banhammer.png',targetPage:'tos'},
		{title:'About',img:'Septagon.png',targetPage:'about'},
		{title:'Settings',img:'settings.png',targetPage:'settings'}
	];
	
bcProfilePageButtons = [
		{title:'Friends',img:'bnet.gif',externPage:'http://www.bungie.net'},
		{title:'Messages',img:'message.png',targetPage:'privacy'}//,
		//{title:'Disconnect from BNet',img:'power.png',targetPage:'tos'}
	];
	
bcTwitterButtons = {
	signedIn:{
		text:'Disconnect from Twitter', className:'bc-twitter-disconnect'
	},
	signedOut:{
		text:'Connect to Twitter', className:'bc-twitter-connect'
	}
};