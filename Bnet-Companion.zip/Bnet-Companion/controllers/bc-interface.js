(function() {
	var interface = new BNetCompanion();
})();